/* Copyright (c) 2017 STMicroelectronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/****************************************************
*           RAPID PROTOTYPING WITH NUCLEO           *
* Example Code 09: DC motor control                 *
* Author: Mauro D'Angelo                            *
* Organization: STMicroelectronics					*
*****************************************************/
#include "mbed.h"

//Define Pin to control PWM
#define PWMA_F PA_7 //pin D11
#define PWMA_B PB_6 //pin D10

//Instantiate an object of PwmOut type called mypwm
PwmOut mypwmaf(PWMA_F);
PwmOut mypwmab(PWMA_B);

//Instantiate an object of DigitalOut type on pin LED1 called myled
DigitalOut myled(LED1);

//Instantiate an object of Serial type on pin Tx and Rx of USB port called pc (being the USB port connected to PC)
Serial pc(USBTX, USBRX);

//Method that changes pwm width to stop DC motor
void stop(void) {
	mypwmaf.pulsewidth(0);
	mypwmab.pulsewidth(0);
}

//Method that changes pwm width to move DC motor forward. The parameter is the percentage of speed with respect to maximum speed.
void goForward(float speed) {
	mypwmaf.pulsewidth(0.01*speed/100);
	mypwmab.pulsewidth(0);
}

//Method that changes pwm width to move DC motor backward. The parameter is the percentage of speed with respect to maximum speed.
void goBackward(float speed) {
	mypwmaf.pulsewidth(0);
	mypwmab.pulsewidth(0.01*speed/100);
}

// Entry point
int main() {
    
    //Set pwm signal period
    mypwmaf.period_ms(10);
    mypwmab.period_ms(10);

    //Define and set percentage parameter
    float percentage = 100;
    //Define and set a flag to set direction of movement
    bool forward = true;

    while(1) {

    	//Toggle LED
    	myled = !myled;

    	//Check direction of movement and act consequently. Print direction and percentage.
    	if(forward && percentage >= 0){
    		goForward(percentage);
    		pc.printf("Percentage forward: %.0f%%\r\n", percentage);
    	}else if (!forward && percentage >= 0){
    		goBackward(percentage);
    		pc.printf("Percentage backward: %.0f%%\r\n", percentage);
    	}

    	//Decrease percentage of 10%
        percentage-=10;

        //If percentage becomes negative reset to 100%
        if(percentage < 0) {
    		percentage = 100;
    		forward=!forward;
        }

        wait(.5);
    }
}
