/*
 * Copyright (c) 2015 ARM Limited. All rights reserved.
 */

#define NS_LIST_FN extern

#include "ns_list.h"


