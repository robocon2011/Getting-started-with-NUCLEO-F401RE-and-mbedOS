/* Copyright (c) 2017 STMicroelectronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
/****************************************************
*           RAPID PROTOTYPING WITH NUCLEO           *
* Example Code 12: Servo motor control and Thread   *
* Author: Mauro D'Angelo                            *
* Organization: STMicroelectronics                  *  
*****************************************************/

#include "mbed.h"
#include "Servo.h"

//Instantiate an object of Servo type on pin PB_3 named servo
Servo servo(PB_3);

//Instantiate an object of DigitalOut type on pin LED1 named myled
DigitalOut myled(LED1);

//Instantiate an object of AnalogIn type named analog_value. Assign it a pin with analog input
AnalogIn analog_value(A0);

//Instantiate an object of Serial type on Tx and Rx pin of USB port named pc (being the USB port connected to PC)
Serial pc(USBTX, USBRX);

Thread thread;

//Define a variable to store analog input
float measure;

// Read variable resistor
void thread_readAnalog(void) {
    while(true){
      //Read analog input value (value from 0.0 to 1.0)
      measure = analog_value.read();
      //Print analog input
      pc.printf("Analog input: %.2f\r\n", measure);
      wait(.25);
   }
}

// Entry point
int main() { 
     
    // Start Thread 
    thread.start(thread_readAnalog);
	//Define a variable to store angle value
	int angle;
    
    while(1) {

        //Calculate angle value
        angle = (int)(measure*180);
    	////Modify servo position
    	servo.write(angle+5);
    	// Print angle
    	pc.printf("Servo set at %d degrees\r\n\n", angle);
        // Modify LED status (toggle)
        myled = !myled;

        wait(.25);

    }
}
