# nanostack-hal-mbed-cmsis-rtos
HAL porting layer for Nanostack on mbed with CMSIS-RTOS
