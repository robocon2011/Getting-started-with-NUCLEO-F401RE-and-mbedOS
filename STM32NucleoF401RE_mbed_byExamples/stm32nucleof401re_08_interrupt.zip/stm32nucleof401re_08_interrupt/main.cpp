/* Copyright (c) 2017 STMicroelectronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/****************************************************
*           RAPID PROTOTYPING WITH NUCLEO           *
* Example Code 08: Interrupt usage                  *
* Author: Mauro D'Angelo                            *
* Organization: STMicroelectronics					*
*****************************************************/

#include "mbed.h"

// It assign an interrupt to the User Button
InterruptIn mybutton(USER_BUTTON);

DigitalOut myled(LED1);

// It is the interval
float delay = 1.0;


// This function is called each time occurs the interrupt
// It modify the blinking interval
void pressed()
{
    if (delay == 1.0)
        delay = 0.2; // 200 ms
    else
        delay = 1.0; // 1 sec
}
 
int main()
{
    // It assigns to the interrupt to the fall edge of the button
    mybutton.fall(&pressed);
    
    // Led blinking
    while (1) {
        myled = !myled;
        wait(delay);
    }
}
 
