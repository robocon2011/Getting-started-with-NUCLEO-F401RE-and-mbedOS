/* Copyright (c) 2017 STMicroelectronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
/****************************************************
*            RAPID PROTOTYPING WITH NUCLEO          *
* Example Code 13: Ultrasound HCSR04                *
* Author: Mauro D'Angelo                            *
* Organization: STMicroelectronics                  *  
*****************************************************/

#include "mbed.h"
#include "hcsr04.h"
 
// It creates an instance of HCSR04, and assigns trigger and echo pins
HCSR04 sensor(PB_8, PB_9);

// Serial connection to PC
Serial pc(USBTX, USBRX);

int main() {

    int i=0;
    int measure[5];
    float averageValue;

    // Main loop
    while(1) {

    	// It starts a 10us pulse on trigger pin
        sensor.start();
        
        // Wait for 100 ms before reading the distance measured
        wait_ms(100);

		// Reading the measure of the distance 
        measure[i] = sensor.get_dist_cm();
        
        i++;

		// It calculates the average every 5 samples
        if(i==5){
            averageValue = sensor.filter(measure, 5);
            // Stampa sulla seriale la misura della distanza in cm
            pc.printf("%.0fcm\r\n", averageValue);
        	i = 0;
        }

    }
}
