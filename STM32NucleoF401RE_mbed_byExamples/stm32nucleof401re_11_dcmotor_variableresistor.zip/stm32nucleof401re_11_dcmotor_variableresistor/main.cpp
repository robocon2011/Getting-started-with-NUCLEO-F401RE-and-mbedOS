/* Copyright (c) 2017 STMicroelectronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
/**********************************************************
*           RAPID PROTOTYPING WITH NUCLEO                 *
* Example Code 11: DC motor control via variable resistor *
* Author: Mauro D'Angelo                            	  *
* Organization: STMicroelectronics				          *  
**********************************************************/
#include "mbed.h"

//Define Pin to control PWM
#define PWMA_F PA_7 //pin D11
#define PWMA_B PB_6 //pin D10

//Instantiate an object of PwmOut type named mypwm
PwmOut mypwmaf(PWMA_F);
PwmOut mypwmab(PWMA_B);

//Instantiate an object of AnalogIn type named analog_value and assign it pin A0
AnalogIn analog_value(A0);

//Instantiate an object of DigitalOut type on pin LED1 named myled
DigitalOut myled(LED1);

//Instantiate an object of Serial type on pin Tx and Rx of USB port named pc (being the USB port connected to PC)
Serial pc(USBTX, USBRX);

//Method that changes pwm width to move DC motor forward. The parameter is the percentage of speed with respect to maximum speed.
void goForward(float perc) {

	mypwmaf.pulsewidth(0.01*perc/100);
	mypwmab.pulsewidth(0);

}

// Entry point
int main() {
    
    //Set pwm signal period
    mypwmaf.period_ms(10);
    mypwmab.period_ms(10);

    //Define and set percentage parameter
    float percentage = 100;
    //Define and set a flag to set direction of movement
    bool forward = true;
    //Define variable to store analog input value;
    float measure;

    while(1) {

    	//Toggle LED
    	myled = !myled;
    	//Read analog input value (value from 0.0 to 1.0)
    	measure = analog_value.read();
    	//Calculate the percentage
    	percentage = measure*100;
    	//Control the motor speed
    	goForward(percentage);
    	//Print percentage
    	pc.printf("Percentage motor speed: %.0f%%\r\n", percentage);

        wait(.2);
    }
}
